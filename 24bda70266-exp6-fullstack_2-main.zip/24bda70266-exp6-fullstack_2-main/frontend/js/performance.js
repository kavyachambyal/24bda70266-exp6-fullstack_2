/**
 * performance.js — Performance Lab: N+1 vs JOIN FETCH vs Cache + Stats
 */

const performance = {
  maxMs: 150, // scale for progress bars

  async runComparison() {
    const btn = document.getElementById("btn-run-comparison");
    btn.disabled = true;
    btn.textContent = "⏳ Running…";

    try {
      // Run all three in sequence (so cache state makes sense)
      await this.runN1();
      await this.runJoinFetch();
      await this.runCached();
      await this.loadCacheStatus();
    } finally {
      btn.disabled = false;
      btn.textContent = "▶ Run Comparison";
    }
  },

  async runN1() {
    const { data, durationMs } = await api.timed("/api/products/n1/list?page=0&size=10");
    document.getElementById("n1-time").textContent = `${durationMs}ms`;
    document.getElementById("n1-queries").textContent = data.queryCount || "–";
    const pct = Math.min((durationMs / this.maxMs) * 100, 100);
    document.getElementById("n1-bar").style.width = pct + "%";
    document.getElementById("n1-explanation").innerHTML =
      `<strong>⚠ N+1 Problem:</strong> ${data.explanation || "Multiple DB round trips for each product's category."}`;
  },

  async runJoinFetch() {
    const { data, durationMs } = await api.timed("/api/products/optimized/list?page=0&size=10");
    document.getElementById("jf-time").textContent = `${durationMs}ms`;
    document.getElementById("jf-queries").textContent = data.queryCount || 1;
    const pct = Math.min((durationMs / this.maxMs) * 100, 100);
    document.getElementById("jf-bar").style.width = pct + "%";
    document.getElementById("jf-explanation").innerHTML =
      `<strong>✅ Optimized:</strong> ${data.explanation || "Single query with JOIN FETCH fetches all data in one round trip."}`;
  },

  async runCached() {
    const { data, durationMs } = await api.timed("/api/products/cached/list?page=0&size=10");
    const hit = data.cacheHit;
    document.getElementById("cache-time").textContent = `${durationMs}ms`;
    document.getElementById("cache-status").textContent = hit ? "HIT ✅" : "MISS ❌";
    document.getElementById("cache-status").style.color = hit ? "var(--accent-green)" : "var(--accent-red)";
    const pct = Math.min((durationMs / this.maxMs) * 100, 5 + Math.random() * 10);
    document.getElementById("cache-bar").style.width = (hit ? pct : Math.min(pct + 20, 60)) + "%";
    document.getElementById("cache-explanation").innerHTML = data.cacheInfo || "–";
  },

  async loadCacheStatus() {
    try {
      const data = await api.get("/api/cache/status");
      document.getElementById("cs-hits").textContent = data.hits;
      document.getElementById("cs-misses").textContent = data.misses;
      document.getElementById("cs-hitrate").textContent = data.hitRate;
      document.getElementById("cs-keys").textContent = data.keyCount;
    } catch (e) {
      console.error("Cache status error:", e);
    }
  },

  async flushCache() {
    await api.delete("/api/cache/flush");
    await this.loadCacheStatus();
    // Reset cache card display
    document.getElementById("cache-time").textContent = "–";
    document.getElementById("cache-status").textContent = "Flushed";
    document.getElementById("cache-status").style.color = "var(--accent-amber)";
    document.getElementById("cache-explanation").textContent = "Cache flushed! Next request will be a MISS.";
    document.getElementById("cache-bar").style.width = "0%";
  },

  async loadStats() {
    try {
      const data = await api.get("/api/products/stats/native");
      const tbody = document.getElementById("stats-tbody");

      if (data.byCategory && data.byCategory.length) {
        tbody.innerHTML = data.byCategory.map((s) => `
          <tr>
            <td><span class="cat-badge">${s.categoryEmoji} ${s.categoryName}</span></td>
            <td>${s.totalProducts.toLocaleString()}</td>
            <td>$${s.avgPrice.toFixed(2)}</td>
            <td>$${s.minPrice.toFixed(2)}</td>
            <td>$${s.maxPrice.toFixed(2)}</td>
            <td class="td-rating">⭐ ${s.avgRating.toFixed(1)}</td>
            <td>${s.totalStock.toLocaleString()}</td>
            <td style="color:var(--accent-green)">${s.inStockCount}</td>
          </tr>
        `).join("") + `
          <tr style="background:var(--bg-elevated);font-weight:700">
            <td>📊 Overall</td>
            <td>${data.overall.totalProducts.toLocaleString()}</td>
            <td>$${data.overall.avgPrice.toFixed(2)}</td>
            <td>–</td>
            <td>–</td>
            <td class="td-rating">⭐ ${data.overall.avgRating.toFixed(1)}</td>
            <td>–</td>
            <td style="color:var(--accent-green)">${data.overall.totalInStock.toLocaleString()}</td>
          </tr>
        `;
      }
    } catch (e) {
      document.getElementById("stats-tbody").innerHTML = `<tr><td colspan="8" class="loading-row" style="color:var(--accent-red)">Error loading stats</td></tr>`;
    }
  },

  async init() {
    await Promise.all([
      this.loadCacheStatus(),
      this.loadStats(),
    ]);
  },
};
