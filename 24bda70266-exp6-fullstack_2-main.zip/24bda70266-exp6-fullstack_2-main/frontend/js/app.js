/**
 * app.js — Main application controller: navigation + initialization
 */

// ── Page Registry ──────────────────────────────────────────────────────────────
const pages = {
  dashboard:  { section: "page-dashboard",  tab: "tab-dashboard",  module: dashboard },
  catalog:    { section: "page-catalog",    tab: "tab-catalog",    module: catalog },
  performance:{ section: "page-performance",tab: "tab-performance",module: performance },
  addproduct: { section: "page-addproduct", tab: "tab-addproduct", module: addProduct },
};

const initialized = new Set();
let currentPage = "dashboard";

/**
 * Navigate to a named page and initialize its module once.
 */
async function navigateTo(page) {
  if (!pages[page]) return;

  // Deactivate all
  Object.values(pages).forEach(({ section, tab }) => {
    document.getElementById(section)?.classList.remove("active");
    document.getElementById(tab)?.classList.remove("active");
  });

  // Activate target
  document.getElementById(pages[page].section)?.classList.add("active");
  document.getElementById(pages[page].tab)?.classList.add("active");

  currentPage = page;

  // Initialize module once (lazy)
  if (!initialized.has(page)) {
    initialized.add(page);
    const mod = pages[page].module;
    if (mod && typeof mod.init === "function") {
      try {
        await mod.init();
      } catch (e) {
        console.error(`Error initializing ${page}:`, e);
      }
    }
  }

  // Scroll to top
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// ── Boot ───────────────────────────────────────────────────────────────────────
(async () => {
  // Start health check
  await checkHealth();
  setInterval(checkHealth, 10000);

  // Load dashboard immediately (default page)
  await navigateTo("dashboard");
})();
