/**
 * dashboard.js — Dashboard page: metric cards + recent products
 */

const dashboard = {
  async load() {
    await Promise.all([
      this.loadStats(),
      this.loadRecentProducts(),
    ]);
  },

  async loadStats() {
    try {
      const { data } = await api.timed("/api/products/stats/native");
      const o = data.overall;

      document.getElementById("mc-total").innerHTML = `
        <span class="mc-icon">📦</span>
        <div class="mc-value">${o.totalProducts.toLocaleString()}</div>
        <div class="mc-label">Total Products</div>
      `;
      document.getElementById("mc-total").className = "metric-card blue";

      document.getElementById("mc-categories").innerHTML = `
        <span class="mc-icon">🗂️</span>
        <div class="mc-value">${data.byCategory.length}</div>
        <div class="mc-label">Categories</div>
      `;
      document.getElementById("mc-categories").className = "metric-card green";

      document.getElementById("mc-avgprice").innerHTML = `
        <span class="mc-icon">💰</span>
        <div class="mc-value">$${o.avgPrice.toFixed(2)}</div>
        <div class="mc-label">Avg Price</div>
      `;
      document.getElementById("mc-avgprice").className = "metric-card amber";

      document.getElementById("mc-avgrating").innerHTML = `
        <span class="mc-icon">⭐</span>
        <div class="mc-value">${o.avgRating.toFixed(1)}</div>
        <div class="mc-label">Avg Rating</div>
      `;
      document.getElementById("mc-avgrating").className = "metric-card purple";

    } catch (e) {
      console.error("Stats load error:", e);
    }
  },

  async loadRecentProducts() {
    try {
      const { data } = await api.timed("/api/products?sortBy=createdAt&direction=desc&size=8");
      const grid = document.getElementById("recent-grid");
      grid.innerHTML = "";
      data.content.forEach((p, i) => {
        const card = document.createElement("div");
        card.className = "product-mini-card";
        card.style.animationDelay = `${i * 0.05}s`;
        card.innerHTML = `
          <div class="pmc-cat">${p.categoryEmoji} ${p.categoryName}</div>
          <div class="pmc-name">${p.name}</div>
          <div class="pmc-price">$${p.price.toFixed(2)}</div>
          <div class="pmc-meta">
            <span class="pmc-rating">${p.rating.toFixed(1)}</span>
            <span class="pmc-reviews">${p.reviewCount.toLocaleString()} reviews</span>
          </div>
        `;
        grid.appendChild(card);
      });
    } catch (e) {
      document.getElementById("recent-grid").innerHTML = "<p style='color:var(--text-muted);padding:1rem'>Failed to load products — is the backend running?</p>";
    }
  },
};
