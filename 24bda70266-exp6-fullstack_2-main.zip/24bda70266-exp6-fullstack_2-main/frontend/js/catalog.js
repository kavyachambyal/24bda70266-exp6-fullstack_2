/**
 * catalog.js — Paginated & Sortable product table
 */

const catalog = {
  currentPage: 0,
  totalPages: 0,
  totalElements: 0,
  pageSize: 10,
  sortField: "id",
  sortDir: "asc",
  searchTimer: null,

  async init() {
    await this.loadCategories();
    await this.fetchProducts();
  },

  async loadCategories() {
    try {
      const data = await api.get("/api/categories");
      const sel = document.getElementById("filter-category");
      data.data.forEach((c) => {
        const opt = document.createElement("option");
        opt.value = c.id;
        opt.textContent = `${c.iconEmoji} ${c.name} (${c.productCount})`;
        sel.appendChild(opt);
      });
    } catch (e) {
      console.error("Category load error:", e);
    }
  },

  async fetchProducts(resetPage = false) {
    if (resetPage) this.currentPage = 0;

    const categoryId = document.getElementById("filter-category").value;
    const search = document.getElementById("filter-search").value.trim();
    this.sortField = document.getElementById("filter-sort").value;
    this.sortDir = document.getElementById("filter-direction").value;
    this.pageSize = parseInt(document.getElementById("filter-size").value);

    const params = {
      page: this.currentPage,
      size: this.pageSize,
      sortBy: this.sortField,
      direction: this.sortDir,
      categoryId: categoryId !== "all" ? categoryId : null,
      search: search || null,
    };

    const qs = api.buildQuery(params);
    const url = `/api/products${qs}`;

    // Show URL in info bar
    document.getElementById("catalog-url-display").textContent = "GET " + url;
    document.getElementById("catalog-timing").textContent = "Loading…";

    // Loading state
    document.getElementById("catalog-tbody").innerHTML = `<tr><td colspan="8" class="loading-row">Fetching data…</td></tr>`;

    try {
      const { data, durationMs } = await api.timed(url);
      this.totalPages = data.page.totalPages;
      this.totalElements = data.page.totalElements;

      // Update timing
      document.getElementById("catalog-timing").textContent = `⏱ ${durationMs}ms — ${data.page.totalElements} results`;

      this.renderTable(data.content);
      this.renderPagination(data.page);
      this.updateSortHeaders();
    } catch (e) {
      document.getElementById("catalog-tbody").innerHTML = `<tr><td colspan="8" class="loading-row" style="color:var(--accent-red)">⚠️ Failed to load — ensure backend is running on port 3001</td></tr>`;
      document.getElementById("catalog-timing").textContent = "Error";
    }
  },

  renderTable(products) {
    const tbody = document.getElementById("catalog-tbody");
    if (!products.length) {
      tbody.innerHTML = `<tr><td colspan="8" class="loading-row">No products found.</td></tr>`;
      return;
    }

    tbody.innerHTML = products.map((p, i) => `
      <tr style="animation-delay:${i * 0.03}s">
        <td class="td-id">#${p.id}</td>
        <td class="td-name" title="${p.name}">${p.name}</td>
        <td><span class="cat-badge">${p.categoryEmoji} ${p.categoryName}</span></td>
        <td class="td-price">$${p.price.toFixed(2)}</td>
        <td class="td-rating">⭐ ${p.rating.toFixed(1)}</td>
        <td class="${p.stock === 0 ? 'td-stock-low' : p.stock < 20 ? 'td-stock-low' : 'td-stock-ok'}">${p.stock === 0 ? '⚠ Out' : p.stock}</td>
        <td>${p.reviewCount.toLocaleString()}</td>
        <td class="td-date">${new Date(p.createdAt).toLocaleDateString()}</td>
      </tr>
    `).join("");
  },

  renderPagination(page) {
    const { number, size, totalElements, totalPages } = page;

    // Info text
    const start = number * size + 1;
    const end = Math.min(start + size - 1, totalElements);
    document.getElementById("page-info").textContent =
      `Showing ${start}–${end} of ${totalElements.toLocaleString()} products`;

    // First / Prev / Next / Last buttons
    document.getElementById("btn-first").disabled = page.first;
    document.getElementById("btn-prev").disabled = page.first;
    document.getElementById("btn-next").disabled = page.last;
    document.getElementById("btn-last").disabled = page.last;

    // Page number buttons (show up to 7 pages around current)
    const numbers = document.getElementById("page-numbers");
    numbers.innerHTML = "";
    const range = this.getPageRange(number, totalPages);
    range.forEach((pn) => {
      if (pn === "…") {
        const el = document.createElement("span");
        el.textContent = "…";
        el.style.cssText = "color:var(--text-muted);padding:0 4px;align-self:center;font-size:0.9rem";
        numbers.appendChild(el);
      } else {
        const btn = document.createElement("button");
        btn.className = `page-btn page-num${pn === number ? " current" : ""}`;
        btn.textContent = pn + 1;
        btn.onclick = () => this.goToPage(pn);
        numbers.appendChild(btn);
      }
    });
  },

  getPageRange(current, total) {
    if (total <= 7) return Array.from({ length: total }, (_, i) => i);
    const pages = [];
    if (current <= 3) {
      for (let i = 0; i < 5; i++) pages.push(i);
      pages.push("…");
      pages.push(total - 1);
    } else if (current >= total - 4) {
      pages.push(0);
      pages.push("…");
      for (let i = total - 5; i < total; i++) pages.push(i);
    } else {
      pages.push(0);
      pages.push("…");
      for (let i = current - 1; i <= current + 1; i++) pages.push(i);
      pages.push("…");
      pages.push(total - 1);
    }
    return pages;
  },

  updateSortHeaders() {
    const cols = ["id", "name", "category", "price", "rating", "stock", "reviews", "date"];
    const fieldMap = { id: "id", name: "name", category: "categoryName", price: "price", rating: "rating", stock: "stock", reviews: "reviewCount", date: "createdAt" };
    cols.forEach((col) => {
      const th = document.getElementById(`th-${col}`);
      if (!th) return;
      th.classList.remove("sorted-asc", "sorted-desc");
      const arrow = th.querySelector(".sort-arrow");
      if (fieldMap[col] === this.sortField) {
        th.classList.add(this.sortDir === "asc" ? "sorted-asc" : "sorted-desc");
        if (arrow) arrow.textContent = this.sortDir === "asc" ? "↑" : "↓";
      } else {
        if (arrow) arrow.textContent = "↕";
      }
    });
  },

  sortBy(field) {
    if (this.sortField === field) {
      this.sortDir = this.sortDir === "asc" ? "desc" : "asc";
    } else {
      this.sortField = field;
      this.sortDir = "asc";
    }
    document.getElementById("filter-sort").value = field;
    document.getElementById("filter-direction").value = this.sortDir;
    this.fetchProducts(true);
  },

  goToPage(n) {
    this.currentPage = n;
    this.fetchProducts();
  },
  prevPage() { if (this.currentPage > 0) { this.currentPage--; this.fetchProducts(); } },
  nextPage() { if (this.currentPage < this.totalPages - 1) { this.currentPage++; this.fetchProducts(); } },
  lastPage() { this.currentPage = this.totalPages - 1; this.fetchProducts(); },

  jumpToPage() {
    const val = parseInt(document.getElementById("jump-input").value) - 1;
    if (!isNaN(val) && val >= 0 && val < this.totalPages) {
      this.goToPage(val);
      document.getElementById("jump-input").value = "";
    }
  },

  changePageSize() {
    this.currentPage = 0;
    this.fetchProducts();
  },

  debounceSearch() {
    clearTimeout(this.searchTimer);
    this.searchTimer = setTimeout(() => this.fetchProducts(true), 400);
  },
};
