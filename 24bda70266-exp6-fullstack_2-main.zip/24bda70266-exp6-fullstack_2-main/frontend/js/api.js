/**
 * api.js — Centralized API layer with timing measurement
 */

const BASE_URL = "http://localhost:3001";

const api = {
  /**
   * Fetch with timing — returns { data, durationMs }
   */
  async timed(url) {
    const t0 = performance.now();
    const res = await fetch(BASE_URL + url);
    const data = await res.json();
    const durationMs = Math.round(performance.now() - t0);
    return { data, durationMs };
  },

  async get(url) {
    const res = await fetch(BASE_URL + url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  },

  async post(url, body) {
    const res = await fetch(BASE_URL + url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    return { data, ok: res.ok, status: res.status };
  },

  async delete(url) {
    const res = await fetch(BASE_URL + url, { method: "DELETE" });
    return res.json();
  },

  /** Build query string from params object, skipping nulls/empty */
  buildQuery(params) {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
      if (v !== null && v !== undefined && v !== "" && v !== "all") qs.append(k, v);
    }
    return qs.toString() ? "?" + qs.toString() : "";
  },
};

/** Health check — update navbar status indicator */
async function checkHealth() {
  const dot = document.getElementById("status-dot");
  const txt = document.getElementById("status-text");
  try {
    const data = await api.get("/health");
    dot.classList.add("online");
    dot.classList.remove("offline");
    txt.textContent = `${data.productCount} products`;
  } catch {
    dot.classList.add("offline");
    dot.classList.remove("online");
    txt.textContent = "Offline";
  }
}
