/**
 * addproduct.js — Add Product form with cache eviction demo
 */

const addProduct = {
  async init() {
    // Load categories for dropdown
    try {
      const data = await api.get("/api/categories");
      const sel = document.getElementById("fp-category");
      sel.innerHTML = '<option value="">Select category…</option>';
      data.data.forEach((c) => {
        const opt = document.createElement("option");
        opt.value = c.id;
        opt.textContent = `${c.iconEmoji} ${c.name}`;
        sel.appendChild(opt);
      });
    } catch (e) {
      console.error("Failed to load categories for form:", e);
    }
  },

  async submit(event) {
    event.preventDefault();
    const btn = document.getElementById("submit-btn");
    btn.disabled = true;
    btn.textContent = "⏳ Submitting…";

    const body = {
      name:        document.getElementById("fp-name").value.trim(),
      price:       document.getElementById("fp-price").value,
      stock:       document.getElementById("fp-stock").value || 0,
      rating:      document.getElementById("fp-rating").value || 4.0,
      reviewCount: document.getElementById("fp-reviews").value || 0,
      categoryId:  document.getElementById("fp-category").value,
      description: document.getElementById("fp-description").value.trim(),
    };

    try {
      const { data, ok, status } = await api.post("/api/products", body);
      const box = document.getElementById("add-response-box");
      const pre = document.getElementById("add-response-pre");

      box.classList.remove("hidden");
      pre.textContent = JSON.stringify(data, null, 2);

      if (ok) {
        pre.style.color = "var(--accent-green)";
        document.getElementById("add-product-form").reset();
        // Reload categories to reflect new product count
        await this.init();
      } else {
        pre.style.color = "var(--accent-red)";
      }
    } catch (e) {
      document.getElementById("add-response-box").classList.remove("hidden");
      document.getElementById("add-response-pre").textContent = "Error: " + e.message;
      document.getElementById("add-response-pre").style.color = "var(--accent-red)";
    } finally {
      btn.disabled = false;
      btn.textContent = "➕ Add Product & Evict Cache";
    }
  },
};
